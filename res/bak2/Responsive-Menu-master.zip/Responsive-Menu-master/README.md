# Responsive Menu
Another ~~jQuery based~~ Vanilla JS Responsive Menu.

*Next thing to do, animate using transform instead of height to take advantage of GPU rendering*
